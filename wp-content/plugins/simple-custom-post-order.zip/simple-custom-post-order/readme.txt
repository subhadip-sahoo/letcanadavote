=== Simple Custom Post Order ===
Contributors: hsameerc
Tags: custom post order, post order, js post order, page order, posts order, category order, sort posts, sort pages, sort custom posts
Requires at least: 3.0.0
Tested up to: 3.9.1
Stable tag: 3.9.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Order posts(posts, any custom post types) using a Drag and Drop Sortable JavaScript. Configuration is unnecessary. 

== Description ==

Order posts(posts, any custom post types) using a Drag and Drop Sortable JavaScript. Configuration is unnecessary. You can do directly on default WordPress administration.
Excluding custom query which uses order or orderby parameters, in get_posts or query_posts and so on.

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress 

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. screenshot-1
2. screenshot-2

== Changelog ==
= Version 1.0 (20-07-2013) =
*  Initial release.

= Version 1.5 (25-07-2013) =
*  Fix : fix errors
*  Added Taxonomy Sort
*  Added Taxonomy Sort option In setting Page

= Version 2.0 (22-11-2013) =
* Fixed Undefined Notice Error in wp version 3.7.1
* Taxonomy Activate Checkbox removed.

= Version 2.1 (31-12-2013) =
* Prevent Breaking autocomplete 

= Version 2.2 (02-07-2014) =
* Fixed bug: Custom Query which uses 'order' or 'orderby' parameters is preferred
* It does not depend on the designation manner of arguments( Parameters ). ( $args = 'orderby=&order=' or $args = array( 'orderby' => '', 'order' => '' ) )
* Previous Versions Issues were Improved.
* Removed Taxonomy Sort( Will add in next Version :) )